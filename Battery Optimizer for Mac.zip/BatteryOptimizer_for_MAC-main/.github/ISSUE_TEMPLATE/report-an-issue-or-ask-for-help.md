---
name: Report an issue or ask for help
about: Is something broken, or are you confused about something?
title: ''
labels: ''
assignees: ''

---

**Your macbook model and year:**

**Your macOS: (run "sw_vers" to find out)**

**Your version number: (run "battery version" to find out)**

**Your battery status: (run "battery status" to find out)**

**What is the issue?**

**Error logs: (run "battery logs" to find out)**
