# Logo compiler

Because Electron does not support SCG images, this little tool takes in percentages to render and generates `.png` files.

To run: `npm start`
Configuration: `modules/comile-images.js`

This only needs to be run if icon percentage support changes.