const render_and_write_template_files = require( './modules/compile-images' )

render_and_write_template_files()